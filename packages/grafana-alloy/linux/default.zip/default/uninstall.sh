#!/bin/sh

rm -rf /opt/grafana-alloy
